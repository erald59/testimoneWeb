const Router = require("./lib/Router");
var router = new Router(6500);

console.log("Started on 6500")
